package com.first.table;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;




public class tables extends AppCompatActivity {

    Button button1,button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,button12,button13,button14,button15,button16,button17,button18,button19,button20;

    int flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tables);

        Toolbar toolbar = findViewById(R.id.toolbar);
        getSupportActionBar(toolbar);
        button1 = findViewById(R.id.table1);
        button2 = findViewById(R.id.table2);
        button3 = findViewById(R.id.table3);
        button4 = findViewById(R.id.table4);
        button5 = findViewById(R.id.table5);
        button6 = findViewById(R.id.table6);
        button7 = findViewById(R.id.table7);
        button8 = findViewById(R.id.table8);
        button9 = findViewById(R.id.table9);
        button10 = findViewById(R.id.table10);
        button11 = findViewById(R.id.table11);
        button12 = findViewById(R.id.table12);
        button13 = findViewById(R.id.table13);
        button14 = findViewById(R.id.table14);
        button15 = findViewById(R.id.table15);
        button16 = findViewById(R.id.table16);
        button17 = findViewById(R.id.table17);
        button18 = findViewById(R.id.table18);
        button19 = findViewById(R.id.table19);
        button20 = findViewById(R.id.table20);



        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=1;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=2;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=3;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=4;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=5;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=6;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=7;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=8;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=9;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=10;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=11;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=12;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=13;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=14;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=15;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=16;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=17;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=18;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=19;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=20;
                Intent intent = new Intent(tables.this, table1.class);
                intent.putExtra("variableKey", flag);
                startActivity(intent);

            }
        });
    }

    private void getSupportActionBar(Toolbar toolbar) {
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}