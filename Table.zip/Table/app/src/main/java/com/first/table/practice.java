package com.first.table;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class practice extends AppCompatActivity {
    private TextView questionTextView ,totalQuestionsTextView;
    private int questionIndex = 0;

    private int correctanswer=0;

    private String[] questions = {
            "7629-6553 = 1075",
            "6884+9963 = 16847",
            "1854 X 278 =515412",
            "1665 / 32 = 52",
            "976 X 488 = 466528"
    };

    private String[] answers= {
            "no","yes","yes","no","no"
    };

    int totalQuestion = answers.length;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practice);
        totalQuestionsTextView = findViewById(R.id.total_question);
        questionTextView = findViewById(R.id.questionTextView);

        totalQuestionsTextView.setText("Total questions : "+totalQuestion);

        displayQuestion();
    }

    public void onYesClick(View view) {
        if (answers[questionIndex]=="yes"){
            correctanswer++;
            Toast.makeText(this, "correct answer", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Incorrect Answer", Toast.LENGTH_SHORT).show();
        }
        questionIndex++;
        displayQuestion();
    }

    public void onNoClick(View view) {
        if (answers[questionIndex]=="no"){
            correctanswer++;
            Toast.makeText(this, "correct answer", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Incorrect Answer", Toast.LENGTH_SHORT).show();
        }
        questionIndex++;
        displayQuestion();
    }

    private void displayQuestion() {
        if (questionIndex < questions.length) {
            String question = questions[questionIndex];
            questionTextView.setText(question);
        } else {
            // All questions answered
            questionTextView.setText("score"+ "="+correctanswer);
            new AlertDialog.Builder(this)
                    .setMessage("Score is "+ correctanswer+" out of "+ totalQuestion)
                    .setPositiveButton("Restart",(dialogInterface, i) -> restartQuiz() )
                    .setCancelable(false)
                    .show();
        }
    }

    void restartQuiz(){
        correctanswer = 0;
        questionIndex =0;
        displayQuestion();

    }
}