package com.first.table;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class table1 extends AppCompatActivity {

    int flag1;

    TextView name,one,two,three,four,five,six,seven,eight,nine,ten;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        getSupportActionBar(toolbar);

        Intent intent = getIntent();
        flag1 = intent.getIntExtra("variableKey", 0);



        one=findViewById(R.id.one);
        name =findViewById(R.id.tablename);
        two=findViewById(R.id.two);
        three=findViewById(R.id.three);
        four=findViewById(R.id.four);
        five=findViewById(R.id.five);
        six=findViewById(R.id.six);
        seven=findViewById(R.id.seven);
        eight=findViewById(R.id.eight);
        nine=findViewById(R.id.nine);
        ten=findViewById(R.id.ten);



        name.setText(flag1+" "+"X");

        one.setText(flag1+"  "+"X"+"  "+"1"+"  "+"="+"  "+(flag1*1));
        two.setText(flag1+"  "+"X"+"  "+"2"+"  "+"="+"  "+(flag1*2));
        three.setText(flag1+"  "+"X"+"  "+"3"+"  "+"="+"  "+(flag1*3));
        four.setText(flag1+"  "+"X"+"  "+"4"+"  "+"="+"  "+(flag1*4));
        five.setText(flag1+"  "+"X"+"  "+"5"+"  "+"="+"  "+(flag1*5));
        six.setText(flag1+"  "+"X"+"  "+"6"+"  "+"="+"  "+(flag1*6));
        seven.setText(flag1+"  "+"X"+"  "+"7"+"  "+"="+"  "+(flag1*7));
        eight.setText(flag1+"  "+"X"+"  "+"8"+"  "+"="+"  "+(flag1*8));
        nine.setText(flag1+"  "+"X"+"  "+"9"+"  "+"="+"  "+(flag1*9));
        ten.setText(flag1+"  "+"X"+"  "+"10"+"  "+"="+"  "+(flag1*10));


    }


    private void getSupportActionBar(Toolbar toolbar) {
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);

    }
}