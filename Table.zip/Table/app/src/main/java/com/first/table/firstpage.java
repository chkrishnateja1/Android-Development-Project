package com.first.table;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

public class firstpage extends AppCompatActivity {

    Button login;
    EditText username;

    String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);

        login=findViewById(R.id.login);
        username=findViewById(R.id.username);
        user = username.getText().toString();




        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(firstpage.this,MainActivity.class);
                intent.putExtra("stringKey",user);
                startActivity(intent);


            }
        });
    }
}